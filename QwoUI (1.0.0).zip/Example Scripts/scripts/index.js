/**
░██████╗░░██╗░░░░░░░██╗░█████╗░  ░░░░░░  ██╗░░░██╗██╗
██╔═══██╗░██║░░██╗░░██║██╔══██╗  ░░░░░░  ██║░░░██║██║
██║██╗██║░╚██╗████╗██╔╝██║░░██║  █████╗  ██║░░░██║██║
╚██████╔╝░░████╔═████║░██║░░██║  ╚════╝  ██║░░░██║██║
░╚═██╔═╝░░░╚██╔╝░╚██╔╝░╚█████╔╝  ░░░░░░  ╚██████╔╝██║
░░░╚═╝░░░░░░╚═╝░░░╚═╝░░░╚════╝░  ░░░░░░  ░╚═════╝░╚═╝

██████╗░██╗░░░██╗  ███╗░░██╗██████╗░███████╗██████╗░███╗░░░███╗░█████╗░
██╔══██╗╚██╗░██╔╝  ████╗░██║██╔══██╗██╔════╝██╔══██╗████╗░████║██╔══██╗
██████╦╝░╚████╔╝░  ██╔██╗██║██████╔╝█████╗░░██████╔╝██╔████╔██║███████║
██╔══██╗░░╚██╔╝░░  ██║╚████║██╔═══╝░██╔══╝░░██╔══██╗██║╚██╔╝██║██╔══██║
██████╦╝░░░██║░░░  ██║░╚███║██║░░░░░███████╗██║░░██║██║░╚═╝░██║██║░░██║
╚═════╝░░░░╚═╝░░░  ╚═╝░░╚══╝╚═╝░░░░░╚══════╝╚═╝░░╚═╝╚═╝░░░░░╚═╝╚═╝░░╚═╝

PLS GIVE CREDIT IF YOU USE THIS Pack for your addon
- YT: @Nperma
*/

import { world, system, Player } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";

/**
 # LAYOUT KEYS
 * blank: §p§0§0
 * disabled: §p§3§0
 * remove-background-button: §b§0§0
 * 
 * modified disabled texture:
 * default: pressed-texture
 * - default: §d§0§1
 * - paperdoll: §d§0§2
 * 
 * modified disabled label:
 * default: minecraftSeven
 * - §t§0§1: MinecraftTen
 * - §t§0§2: MinecraftTen
 * 
 * structure:
 * - right third: §p1§1
 * - right half: §p§1§2
 * - left third: §p§2§1
 * - left half: §p§2§2
 * 
 * size:
 * - default: 30
 * - 60: §s§s§1
 * - 90: §s§s§2
 * - 120: §s§s§3
 * - 150: §s§s§4
 * 
 * header-button:
 * - left arrow: §p§4§0
 * - right arrow: §p§4§1
 * - faq: §p§4§2
 * - warn: §p§4§3
 */

function TestUI(player) {
    const fun = new ActionFormData()
        .title("Qwo - UI")
        .body("Default UI")
        .button("Default")
        .button("Disabled§p§3§0§p§0§0§p§2§1§p§2§2")
        .button("Hello Everyone§p§1§1")
        .button("Next")
        .show(ev.player)
        .then(r => {
            if (r.canceled) return;

            function TestUI2(player) {
                new ActionFormData()
                    .title("Qwo - UI§f§0§1")
                    .button("Back§p§4§0")
                    .button("Next§p§4§1")
                    .button("§p§0§0§p§3§0§p§2§1§d§0§2§s§s§3§b§0§0")
                    .button("[INFORMATION]§t§0§2§p§3§0§d§0§1§p§1§1§p§1§2")
                    .button(`[MCdevID]§p§3§0§p§1§2§p§1§1`)
                    .button(`LVL: 999§p§3§0§p§1§2§p§1§1`)
                    .button(`Shark V4§p§3§0§p§1§2§p§1§1`)
                    .button("List - Devs§p§3§0§d§0§1§t§0§2")
                    .button("[ !Nperma ]§p§0§0§p§2§1§p§2§2§s§s§1§p§3§0", "textures/ui/csb_faq_fox")
                    .button("[ Fary ]§p§0§0§p§1§1§p§2§1§p§3§0§s§s§1", "textures/ui/csb_faq_bee")
                    .button("[ Snaky ]§p§1§1§p§1§2§s§s§1§p§3§0", "textures/ui/csb_faq_horse")
                    .button("[ Andy ]§p§0§0§p§2§1§p§2§2§s§s§1§p§3§0", "textures/ui/csb_faq_parrot")
                    .button("[ Alvin ]§p§0§0§p§1§1§p§2§1§p§3§0§s§s§1", "textures/ui/csb_faq_pig")
                    .button("[ !Nandog ]§p§1§1§p§1§2§s§s§1§p§3§0", "textures/ui/Friend2")
                    .button("SNAP - PREVIEW§s§s§2§p§3§0", "textures/ui/Black")
                    .show(player)
                    .then(r => {
                        if (r.canceled) return;

                        if (r.selection === 0) TestUI(player);
                        else if (r.selection === 1)
                            new ActionFormData()
                                .title("Qwo - UI")
                                .button("Back§p§4§0")
                                .button("More Information\n§dclick here§p§4§2")
                                .button("Bedrock Addons Creator§p§3§0§t§0§2")
                                .button("VoidMC§p§3§0§b§0§0")
                                .button("JustSkyDev§p§3§0§b§0§0")
                                .button("pipa_ngry§p§3§0§b§0§0")
                                .button("TheoristMC§p§3§0§b§0§0")
                                .button("Full Thanks For All ;)§p§3§0§s§s§2", "textures/ui/enable_editor")
                                .show(player)
                                .then(r => {
                                    if (r.canceled) return;

                                    if (r.selection === 0) TestUI2(player);
                                });
                        else if (r.selection === 1) player.sendMessage("Thanks For Support Me :> (Nperma)");
                    });
            }

            if (r.selection === 3) TestUI2(player);
        });
}

world.afterEvents.playerSpawn.subscribe(async ev => {
    if (ev.initialSpawn) {
        await null;
        if (!world.getDynamicProperty(ev.player.id)) {
            ev.player.sendMessage("Hello Creator :>, wanna try QwoUI, right click stick for open ui. make your modified be better than S0meOne.");
            world.setDynamicProperty(ev.player.id, true);
        }
    }
});

world.beforeEvents.itemUse.subscribe(ev => {
    if (ev.itemStack?.typeId !== "minecraft:stick") return;
    system.run(() => {
        TestUI(ev.source);
    });
});
